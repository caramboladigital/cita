﻿<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset='utf-8'>
<link rel="stylesheet" type="text/css" href="estilos/reset.css">
<link rel="stylesheet" type="text/css" href="estilos/estilo-base.css">
<link rel="stylesheet" type="text/css" href="estilos/pesquisa.css">
</head>
<body>
<div class="linha cabec">
	<div class="col-12">
		 <img id='logo' src='imagens/maos.jpg'>
		 <center> <h1 class="tit">Meus &nbsp Contatos</h1> </center>
	</div>
</div>
<div class="linha">
	<div class="col-12">
    <center><button class="botao" onclick=location.href="pesqNome.html">Voltar</button></center>
	</div>
</div>	
<?php
include "conexao.php";
mysqli_set_charset($con,"utf8");
$pesq=$_POST['nome'];

$sql="SELECT * FROM contatos WHERE nome like '$pesq%'";
	
$busca = mysqli_query($con,$sql); // excuta o sql
$linhas=$busca->num_rows; // verifica se achou tem pelo menos 1 linha , senão não achou $linhas = 0

if ($linhas==0){
   //echo "<script>alert('CONTATO NÃO CADASTRADO');window.location.href='pesqNome.html';</script>";
   	session_start();
    $_SESSION["msg"]="Nome do Usuário não Cadastrado";
    header('location:mensagemErro.php');
    }
 else {  
	$dados =   mysqli_fetch_array($busca); // cria um vetor, neste caso no $dados contendo os dados de cada campo
	$nome=     $dados['nome'];
	$email=    $dados['email'];
	$dtaniv=   $dados['dtaniv'];
	$estado=   $dados['estado'];
	$dataP = explode('-', $dtaniv);
    $dtaniv = $dataP[2].'/'.$dataP[1].'/'.$dataP[0];
 }
?>

<div class="linha"> 
	
	<div class="col-12 mostraDados">
	<?php
		echo "<p>Nome:.................&nbsp&nbsp" .$nome   . "</p><br>";
		echo "<p>Email:................&nbsp&nbsp" .$email  . "</p><br>";
		echo "<p>Dt. Aniv:.............&nbsp&nbsp" .$dtaniv . "</p><br>";
		echo "<p>Estado:...............&nbsp&nbsp" .$estado . "</p><br>";
	?>
	</div>
	
 
</div>

</body>
</html>



