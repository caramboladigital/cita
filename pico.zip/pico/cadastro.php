﻿<?php

include "conexao.php";

$usuario=  $_POST['usuario'];
$senha=    $_POST['senha'];
$nome=     $_POST['nome'];
$email=    $_POST['email'];
$dtaniv=   $_POST['dtaniv'];
$estado=   $_POST['estado'];

//$dataP = explode('/', $dtaniv);
//$dtaniv= $dataP[2].'-'.$dataP[1].'-'.$dataP[0];

$sql="SELECT * FROM contatos WHERE usuario = '$usuario'";

$busca = mysqli_query($con,$sql); // excuta o sql
$linhas=$busca->num_rows; // verifica a quantidade de linhas que voltou do Select

if ($linhas!=0){
   echo "<script>alert('USUARIO JÁ EXISTE NO SISTEMA');window.location.href='index.html';</script>";
    }
 else {
   $sql="insert into contatos(usuario,senha,nome,email,dtaniv,estado) values ('$usuario','$senha','$nome','$email','$dtaniv','$estado')";
   mysqli_query($con,$sql) ;
   mysqli_close($con);
   header('location:index.html');
 }
 


?>

