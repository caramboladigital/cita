﻿<?php
//conecção com o servidor

$usuario="root";
$senha="";

//$usuario = "001aluno";
//$senha = "123456";

$host="localhost";
$banco = "bdmeuscontatos";

$con=mysqli_connect($host, $usuario,$senha,$banco);
if (mysqli_connect_errno())
  {
  echo "Falha na conexao com o MySQL: " . mysqli_connect_error();
  
}
?>