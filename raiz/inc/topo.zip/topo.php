    <div id="topo">
        <div id="logoCitacoes"><a href="buscaPorPalavra.php"><img src="img/logo-citacoes.png"></a></div>
        <div id="logoCarambola"><img src="img/logo-carambola.png"></div>
    </div>
    <div class="menu">
        <div class="dropdown">
            <div class="capomenu"><a href="index.php">BUSCA POR PALAVRA-CHAVE</a></div>
            <div class="capomenu"><a href="incluiAutorPublicacao.php">NOVA PUBLICAÇÃO</a> </div>
            <div class="capomenu"><a href="listaAutorPublicacao.php">LISTA PUBLICAÇÕES</a></div>
            <div class="capomenu"><a href="listaAutor.php">LISTA AUTORES</a></div>
            <div class="capomenu"><a href="listaPalavra.php">LISTA PALAVRA-CHAVE</a></div>
            <div class="capomenu"><a href="listaSaudeDbCheckUp.php">CHECK UP DB</a></div>
            <div class="capomenu"><a href="logout.php">LOGOUT</a></div>
        </div>
    </div>
    <div class="espaco30"></div>
