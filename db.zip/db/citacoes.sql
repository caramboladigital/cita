-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 19-Set-2020 às 19:12
-- Versão do servidor: 5.6.20-log
-- PHP Version: 7.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `citacoes`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `autor`
--

CREATE TABLE IF NOT EXISTS `autor` (
`IdAutor` int(11) NOT NULL,
  `AutNome` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `AutSobrenome` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Autores' AUTO_INCREMENT=12 ;

--
-- Extraindo dados da tabela `autor`
--

INSERT INTO `autor` (`IdAutor`, `AutNome`, `AutSobrenome`) VALUES
(1, 'Clay', 'SHIRKY'),
(2, 'Yochai', 'BENKLER'),
(3, 'Lisa', 'GANSKY'),
(4, 'Gavin', 'AMBROSE'),
(5, 'Chris', 'ANDERSON'),
(6, 'Hans', 'ARP'),
(7, 'Robert', 'AXELROD'),
(8, 'Michael', 'COHEN'),
(9, 'D.', 'TAPSCOTT'),
(10, 'A. ', 'WILLIAMS'),
(11, 'Ernst', 'CASSIRER');

-- --------------------------------------------------------

--
-- Estrutura da tabela `aut_pub`
--

CREATE TABLE IF NOT EXISTS `aut_pub` (
`IdAutPub` int(11) NOT NULL,
  `IdAutor` int(11) NOT NULL,
  `IdPublicacao` int(11) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Extraindo dados da tabela `aut_pub`
--

INSERT INTO `aut_pub` (`IdAutPub`, `IdAutor`, `IdPublicacao`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 5, 3),
(4, 7, 4),
(5, 8, 4),
(6, 9, 5),
(7, 10, 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `citacao`
--

CREATE TABLE IF NOT EXISTS `citacao` (
`IdCitacao` int(11) NOT NULL,
  `CitCitacao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `CitPg` int(6) DEFAULT NULL,
  `CitComentario` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `IdPub` int(11) NOT NULL COMMENT 'chave externa'
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Extraindo dados da tabela `citacao`
--

INSERT INTO `citacao` (`IdCitacao`, `CitCitacao`, `CitPg`, `CitComentario`, `IdPub`) VALUES
(2, 'Such systems challenge understanding as well as prediction. These difficulties are familiar to anyone who has seen small changes unleash major consequences. Conversely, they are familiar to anyone who has been surprised when large changes in policies or tools produce no long-run change in people''s behavior. ', NULL, 'desproporcionalidade entre causa e efeito: pequena causa pode gerar grande efeito, e grande causa pode gerar pequeno efeito.', 4),
(3, 'Even though moths in England could not understand or predict that the Industrial Revolution would turn white-barked trees into soot-covered trees, it did not take very long for selection by predatory birds to transform the population of moths near a factory from white to black. ', 3, 'no prefÃ¡cio', 4),
(4, 'More business school courses and businesses themselves began to emphasize and experiment with organizational models that were neither strictly market-based nor as hierarchical as had been thought necessary in the past. Instead they were built around the assumption that, given the right conditions, people would opt to cooperate and collaborate to serve the collective good of the organization â€” of their own free will. More radical still, the rise of peer production on the Net â€” from free and open-source software, to Wikipedia, to collaborative citizen journalism on sites like Daily Kos or Newsvine, to social networks like Facebook and Twitter â€” produced a culture of cooperation that was widely thought impossible a mere ï¬ve or ten years ago.\r\n(...)\r\nIn fact, in hundreds of studies, conducted in numerous disciplines across dozens of societies, a basic pattern\r\nemerges. In any given experiment, a large minority of people (about 30 percent) behave as though they really are selfish, as the mainstream commonly assumes. But here is the rub:\r\nFully half of all people systematically, significantly, and predictably behave cooperatively.Some of them cooperate conditionally â€” they treat kindness with kindness, and meanness with meanness. Others are unconditional cooperators, or altruists, who cooperate even when it comes at a personal cost. The\r\npoint is, across a wide range of experiments, in widely diverse populations, one finding stands out: In practically no human society examined under controlled conditions have the majority of people consistently behaved selfishly. ', 11, '', 2),
(5, 'This adoption of cooperative systems in so many fields has been paralleled by a renewed interest among researchers in the social and behavioral sciences in the mechanics of cooperation. Perhaps humankind might not be so inherently selfish after all. Through the work of hundreds of scientists, we have begun to see mounting evidence in psychology, organizational sociology, political science, experimental economics, and elsewhere that people are in fact more cooperative and selfless, or at least behave far less selfishly, than most economists and others previously assumed. This isn''t just theory; dozens of field studies have identified cooperative systems, often more stable and effective than equivalent incentive- based ones. Even in the study\r\nof human biology, evolutionary biologists and psychologists are now finding neural and possibly genetic evidence of a human predisposition to cooperate. Though it may sound counterintuitive, there is much evidence that evolution may actually favor individuals (and societies that include these individuals) who are driven to cooperate with or help others, even at cost to themselves. ', 13, NULL, 2),
(6, '(...) dozens of field studies have identified cooperative systems, often more stable and effective than equivalent incentive-based ones. Even in the study of human biology, evolutionary biologists and psychologists are now finding neural and possibly genetic evidence of a human predisposition to cooperate.', 6, '', 2),
(7, 'Why do so many of us still cling to this grossly unflattering view of the human species as a selfish animal? Why do we persist even in the face of so much evidence to the contrary? Why do we assume the worst about humankind?\r\nI think there are four reasons: one, the fact that the assumption of human self- interest is partially correct; two, the historical moment at which the concept of selfishness and self- interest rose to prominence in our culture; three, our desire for simple, clear, elegant explanations about our-selves and the world in which we live (even if those simple explanations are wrong); and four, the mere force of habit and its ability to distort our perception and thinking.  ', 15, NULL, 2),
(8, 'Had he presented his mission in completely self-interested terms (-- Help my friend save 300!--) or in unattainably general ones (\r\nLet''s fight theft everywhere!, the tools he chose wouldn''t have mattered. What he did was to work out a message framed in big enough terms to inspire interest, yet achievable enough to inspire confidence. (This sweet spot is what Eric Raymond, the theorist of open source software, calls ''a plausible promise.'') Without a plausible promise, all the technology in the world would be nothing more than all the technology in the world.', 8, '', 1),
(9, 'In a way, every institution lives in a kind of contradiction: it exists to take advantage of group effort, but some of its resources are drained away by directing that effort. Call this the institutional dilemma -- because an institution expends resources to manage resources, there is a gap between what those institutions are capable of in theory and in practice, and the larger the institution, the greater those costs. ', 9, '', 1),
(10, 'We now have communications tools that are flexible enough to match our social capabilities, and we are witnessing the rise of new ways of coordinating action that take advantage of that change... we are living in the middle of a remarkable increase in our ability to share, to cooperate with one another, and to take collective action, all outside the framework of traditional institutions and organizations.', 10, '', 1),
(11, 'Smart companies are encouraging, rather than fighting, the heaving growth of massive online communities -- many of which emerged from the fringes of the Web to attract tens of millions of participants overnight. Even ardent competitors are collaborating on path-breaking scientific initiatives that accelerate discovery in their industries. Indeed, as a growing number of firms see the benefits of mass collaboration, this new way of organizing will eventually displace the traditional corporate structures as the economyâ€™s primary engine of wealth creation.', 11, '', 5),
(12, 'While hierarchies are not vanishing, profound changes in the nature of technology, demographics, and the global economy are giving rise to powerful new models of production based on community, collaboration, and self-organization rather than on hierarchy and control.', 1, NULL, 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `cit_pal`
--

CREATE TABLE IF NOT EXISTS `cit_pal` (
`IdCitPal` int(11) NOT NULL,
  `IdCitacao` int(11) NOT NULL,
  `IdPalavra` int(11) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Extraindo dados da tabela `cit_pal`
--

INSERT INTO `cit_pal` (`IdCitPal`, `IdCitacao`, `IdPalavra`) VALUES
(1, 4, 1),
(2, 4, 2),
(3, 5, 1),
(4, 6, 1),
(5, 7, 1),
(6, 7, 3),
(7, 2, 4),
(8, 3, 5),
(9, 10, 1),
(10, 10, 6),
(11, 8, 1),
(12, 8, 7),
(13, 9, 1),
(14, 11, 1),
(15, 11, 9),
(16, 11, 8),
(17, 12, 1),
(18, 12, 10),
(19, 12, 9);

-- --------------------------------------------------------

--
-- Estrutura da tabela `palavra`
--

CREATE TABLE IF NOT EXISTS `palavra` (
`IdPalavra` int(11) NOT NULL,
  `PalPalavra` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Extraindo dados da tabela `palavra`
--

INSERT INTO `palavra` (`IdPalavra`, `PalPalavra`) VALUES
(8, 'wisdom of the crowds'),
(7, 'institutional dilemma'),
(6, 'plausible promise'),
(5, 'evoluÃ§Ã£o'),
(4, 'sistemas complexos'),
(3, 'crowdsourcing'),
(2, 'wikipedia'),
(9, 'economia'),
(1, 'colaboraÃ§Ã£o'),
(10, 'auto-organizaÃ§Ã£o'),
(25, 'dezesseis'),
(26, 'dezessete'),
(27, 'cento e trÃªs');

-- --------------------------------------------------------

--
-- Estrutura da tabela `publicacao`
--

CREATE TABLE IF NOT EXISTS `publicacao` (
`IdPublicacao` int(11) NOT NULL,
  `PubTitulo` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `PubLocal` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `PubEditora` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `PubAno` int(11) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Publicações' AUTO_INCREMENT=6 ;

--
-- Extraindo dados da tabela `publicacao`
--

INSERT INTO `publicacao` (`IdPublicacao`, `PubTitulo`, `PubLocal`, `PubEditora`, `PubAno`) VALUES
(1, 'Here comes everybody', 'New York', 'Penguin Books', 2008),
(2, 'The Penguin and the Leviathan', 'New York', 'Random House Audio', 2011),
(3, 'The long tail', 'New York', 'Hyperion Books', 2006),
(4, 'Harnessing complexity', 'New York', 'Basic Books', 2000),
(5, 'Wikinomics. How mass collaboration changes everything', 'New York', 'Penguin Books', 2007);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `autor`
--
ALTER TABLE `autor`
 ADD PRIMARY KEY (`IdAutor`);

--
-- Indexes for table `aut_pub`
--
ALTER TABLE `aut_pub`
 ADD PRIMARY KEY (`IdAutPub`);

--
-- Indexes for table `citacao`
--
ALTER TABLE `citacao`
 ADD PRIMARY KEY (`IdCitacao`);

--
-- Indexes for table `cit_pal`
--
ALTER TABLE `cit_pal`
 ADD PRIMARY KEY (`IdCitPal`);

--
-- Indexes for table `palavra`
--
ALTER TABLE `palavra`
 ADD PRIMARY KEY (`IdPalavra`);

--
-- Indexes for table `publicacao`
--
ALTER TABLE `publicacao`
 ADD PRIMARY KEY (`IdPublicacao`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `autor`
--
ALTER TABLE `autor`
MODIFY `IdAutor` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `aut_pub`
--
ALTER TABLE `aut_pub`
MODIFY `IdAutPub` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `citacao`
--
ALTER TABLE `citacao`
MODIFY `IdCitacao` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `cit_pal`
--
ALTER TABLE `cit_pal`
MODIFY `IdCitPal` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `palavra`
--
ALTER TABLE `palavra`
MODIFY `IdPalavra` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `publicacao`
--
ALTER TABLE `publicacao`
MODIFY `IdPublicacao` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
